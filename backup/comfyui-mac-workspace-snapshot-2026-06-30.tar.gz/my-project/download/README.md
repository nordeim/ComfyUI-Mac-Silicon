# download/ — Final Deliverables

This folder contains the user-facing deliverables from the v1.5 update.

## Contents

| File / Folder | Purpose | Size |
|---|---|---|
| `comfyui-set-mac-SKILL.md` | **v1.5 SKILL.md** — the main ComfyUI Mac install guide (2,917 lines, 14k words) | 110 KB |
| `research/mlx-image-gen-mac-2026.md` | **Research report** — 11,570 words, 49 cited sources, deep technical analysis | 84 KB |
| `research/scripts/` | **10 companion Python scripts** — production-ready, MIT-licensed, runnable via `uv run` | 21 KB |
| `research/scripts/README.md` | Quick start guide for the 10 scripts | 2.5 KB |

## Quick start

```bash
# Read the main install guide
less comfyui-set-mac-SKILL.md

# Run the first companion script
uv run research/scripts/01_z_image_turbo_basic.py
```

## What's new in v1.5

The v1.5 SKILL.md expands the v1.4 baseline (1,442 lines → 2,917 lines) with:

- 4 critical update notices (DiffusionKit archived, mflux 0.18.0 Python API, M5 macOS 26.2+, Ideogram 4 MLX branch)
- Model Landscape expanded from 3 to 9 families
- Runtime Methods expanded from 3 to 7
- 5 new pitfalls (16-20)
- New Section 11 (Production Deployment Patterns)
- New Section 12 (License Audit for commercial use)
- New Appendix D (Companion Scripts Manifest)
- New Appendix E (Migration Guide v1.4 → v1.5)
- 34 references to the 10 companion Python scripts
- 15 cross-references to the research report

See the v1.5 changelog entry in `comfyui-set-mac-SKILL.md` for the full list of changes.

## Companion scripts

The 10 scripts in `research/scripts/` are self-contained `uv run --script` Python files with inline dependencies — no virtualenv setup required.

| Script | Purpose |
|---|---|
| `01_z_image_turbo_basic.py` | Minimal mflux Python API — Z-Image Turbo int8 |
| `02_production_server.py` | FastAPI OpenAI-compatible image server |
| `03_multi_lora.py` | Multi-LoRA loading with scales |
| `04_image_to_image.py` | Image-to-image editing |
| `05_controlnet_depth.py` | ControlNet Canny + Depth Pro pipeline |
| `06_live_preview.py` | Live preview with mlx-taef TAE decoder |
| `07_teacache_speedup.py` | TeaCache step-skipping (30-50% speedup) |
| `08_metadata_reproducibility.py` | Metadata export + reproduce workflow |
| `09_benchmark_harness.py` | Benchmark harness for hardware validation |
| `10_commercial_safe_pipeline.py` | Commercial-safe pipeline (FLUX.2 klein 4B, Apache 2.0) |

See `research/scripts/README.md` for full details.

## Related artifacts

- **Workspace README:** `../README.md` (top-level workspace overview)
- **Workspace MANIFEST:** `../MANIFEST.txt` (exact file list with sizes)
- **v1.4 baseline:** `../upload/comfyui-set-mac-SKILL.md` (for diff comparison)
- **Research audit trail:** `../research/notes/` (14 clean-text primary source extracts)
